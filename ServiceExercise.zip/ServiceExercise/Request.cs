﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConnectionPool {
    public class Request {
        public int Command { get; set; }
    }
}
